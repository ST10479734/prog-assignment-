use raceday

create table users(
user_ID int identity(1,1) primary key,
fullname varchar(100) not null,
role varchar(50) not null,
email varchar (100) not null,
password varchar (255)not null);

create table events(
event_ID int identity (1,1) primary key,
organizer_ID int not null,
CONSTRAINT FK_Events_Users
FOREIGN KEY (organizer_ID)
REFERENCES USERS (user_ID),
eventname VARCHAR(150) NOT NULL, 
location VARCHAR(200) NOT NULL, 
eventdate DATETIME NOT NULL);

CREATE TABLE ROUTES (
route_ID INT IDENTITY(1,1) PRIMARY KEY,
event_ID INT NOT NULL,
CONSTRAINT FK_Routes_Events FOREIGN KEY (event_ID)
REFERENCES EVENTS(event_ID),
startpoint VARCHAR(200) NOT NULL);

CREATE TABLE CATEGORIES (
category_ID INT IDENTITY (1,1) PRIMARY KEY,
event_ID INT NOT NULL, 
CONSTRAINT FK_Categories_Events FOREIGN KEY (event_ID)
REFERENCES EVENTS (event_ID),
distance DECIMAL (5,2) NOT NULL,
categoryname VARCHAR(50) NOT NULL);

CREATE TABLE ENROLMENTS (
enrolment_ID INT IDENTITY(1,1) PRIMARY KEY,
user_ID INT NOT NULL,
category_ID INT NOT NULL,
racenumber VARCHAR(20) NOT NULL,
paymentstatus VARCHAR(20),
CONSTRAINT FK_Enrolments_Users 
FOREIGN KEY (user_ID)
REFERENCES USERS (user_ID),
CONSTRAINT FK_Enrolments_Categories FOREIGN KEY (category_ID)
REFERENCES CATEGORIES (category_ID),
CONSTRAINT UQ_User_Category UNIQUE (user_ID,category_ID)); 

CREATE TABLE PAYMENT(
payment_ID INT IDENTITY (1, 1) PRIMARY KEY,
enrolment_ID INT NOT NULL,
amount DECIMAL (10,2) NOT NULL,
paymentdate int not null,
method VARCHAR(50) NOT NULL,
CONSTRAINT FK_Payment_Enrolments 
FOREIGN KEY (enrolment_ID)
REFERENCES ENROLMENTS(enrolment_ID));

CREATE TABLE RESULTS (
results_ID INT IDENTITY(1,1) PRIMARY KEY,
enrolment_ID INT NOT NULL,
finishtime TIME NOT NULL,
overallposition INT NOT NULL,
categoryposition INT NOT NULL,
CONSTRAINT FK_Results_Enrolments FOREIGN KEY (enrolment_ID)
REFERENCES ENROLMENTS(enrolment_ID));
